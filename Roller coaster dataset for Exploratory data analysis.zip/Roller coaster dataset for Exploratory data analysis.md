```python
import pandas as pd
import numpy as np
import matplotlib.pylab as plt
import seaborn as sns
plt.style.use('ggplot')
#pd.set_option('max_columns',200)
```


```python
df=pd.read_csv('C:/Users/LENOVO X260/Desktop/seyi/coaster_db.csv')
```

Understanding Roller coaster dataset


```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>coaster_name</th>
      <th>Length</th>
      <th>Speed</th>
      <th>Location</th>
      <th>Status</th>
      <th>Opening date</th>
      <th>Type</th>
      <th>Manufacturer</th>
      <th>Height restriction</th>
      <th>Model</th>
      <th>...</th>
      <th>speed1</th>
      <th>speed2</th>
      <th>speed1_value</th>
      <th>speed1_unit</th>
      <th>speed_mph</th>
      <th>height_value</th>
      <th>height_unit</th>
      <th>height_ft</th>
      <th>Inversions_clean</th>
      <th>Gforce_clean</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Switchback Railway</td>
      <td>600 ft (180 m)</td>
      <td>6 mph (9.7 km/h)</td>
      <td>Coney Island</td>
      <td>Removed</td>
      <td>June 16, 1884</td>
      <td>Wood</td>
      <td>LaMarcus Adna Thompson</td>
      <td>NaN</td>
      <td>Lift Packed</td>
      <td>...</td>
      <td>6 mph</td>
      <td>9.7 km/h</td>
      <td>6.0</td>
      <td>mph</td>
      <td>6.0</td>
      <td>50.0</td>
      <td>ft</td>
      <td>NaN</td>
      <td>0</td>
      <td>2.9</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Flip Flap Railway</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Sea Lion Park</td>
      <td>Removed</td>
      <td>1895</td>
      <td>Wood</td>
      <td>Lina Beecher</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>12.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Switchback Railway (Euclid Beach Park)</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Cleveland, Ohio, United States</td>
      <td>Closed</td>
      <td>NaN</td>
      <td>Other</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Loop the Loop (Coney Island)</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Other</td>
      <td>Removed</td>
      <td>1901</td>
      <td>Steel</td>
      <td>Edwin Prescott</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Loop the Loop (Young's Pier)</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Other</td>
      <td>Removed</td>
      <td>1901</td>
      <td>Steel</td>
      <td>Edwin Prescott</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1082</th>
      <td>American Dreier Looping</td>
      <td>3,444 ft (1,050 m)</td>
      <td>53 mph (85 km/h)</td>
      <td>Other</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Steel</td>
      <td>Anton Schwarzkopf</td>
      <td>55 in (140 cm)</td>
      <td>NaN</td>
      <td>...</td>
      <td>53 mph</td>
      <td>85 km/h</td>
      <td>53.0</td>
      <td>mph</td>
      <td>53.0</td>
      <td>111.0</td>
      <td>ft</td>
      <td>NaN</td>
      <td>3</td>
      <td>4.7</td>
    </tr>
    <tr>
      <th>1083</th>
      <td>Pantheon (roller coaster)</td>
      <td>3,328 ft (1,014 m)</td>
      <td>73 mph (117 km/h)</td>
      <td>Busch Gardens Williamsburg</td>
      <td>Under construction</td>
      <td>2022</td>
      <td>Steel – Launched</td>
      <td>Intamin</td>
      <td>NaN</td>
      <td>Blitz Coaster</td>
      <td>...</td>
      <td>73 mph</td>
      <td>117 km/h</td>
      <td>73.0</td>
      <td>mph</td>
      <td>73.0</td>
      <td>178.0</td>
      <td>ft</td>
      <td>NaN</td>
      <td>2</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1084</th>
      <td>Tron Lightcycle Power Run</td>
      <td>3,169.3 ft (966.0 m)</td>
      <td>59.3[1] mph (95.4 km/h)</td>
      <td>Other</td>
      <td>NaN</td>
      <td>June 16, 2016</td>
      <td>Steel – Launched</td>
      <td>Vekoma</td>
      <td>4[2] ft (122 cm)</td>
      <td>Motorbike roller coaster</td>
      <td>...</td>
      <td>59.3 mph</td>
      <td>95.4 km/h</td>
      <td>59.3</td>
      <td>mph</td>
      <td>59.3</td>
      <td>78.1</td>
      <td>ft</td>
      <td>NaN</td>
      <td>0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>1085</th>
      <td>Tumbili</td>
      <td>770 ft (230 m)</td>
      <td>34 mph (55 km/h)</td>
      <td>Kings Dominion</td>
      <td>Under construction</td>
      <td>NaN</td>
      <td>Steel – 4th Dimension – Wing Coaster</td>
      <td>S&amp;S – Sansei Technologies</td>
      <td>NaN</td>
      <td>4D Free Spin</td>
      <td>...</td>
      <td>34 mph</td>
      <td>55 km/h</td>
      <td>34.0</td>
      <td>mph</td>
      <td>34.0</td>
      <td>112.0</td>
      <td>ft</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1086</th>
      <td>Wonder Woman Flight of Courage</td>
      <td>3,300 ft (1,000 m)</td>
      <td>58 mph (93 km/h)</td>
      <td>Six Flags Magic Mountain</td>
      <td>Under construction</td>
      <td>2022</td>
      <td>Steel – Single-rail</td>
      <td>Rocky Mountain Construction</td>
      <td>NaN</td>
      <td>Raptor – Custom</td>
      <td>...</td>
      <td>58 mph</td>
      <td>93 km/h</td>
      <td>58.0</td>
      <td>mph</td>
      <td>58.0</td>
      <td>131.0</td>
      <td>ft</td>
      <td>NaN</td>
      <td>3</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>1087 rows × 56 columns</p>
</div>




```python
df=df[['coaster_name', 
     #'Length', 'Speed', 
     'Location', 'Status', 
     #'Opening date',
      # 'Type', 'Manufacturer', 'Height restriction', 'Model', 'Height',
       'Inversions', 
     #'Lift/launch system', 'Cost', 'Trains', 'Park section',
     #  'Duration', 'Capacity', 'G-force', 'Designer', 'Max vertical angle',
     #  'Drop', 'Soft opening date', 'Fast Lane available', 'Replaced',
       #'Track layout', 'Fastrack available', 'Soft opening date.1',
       #'Closing date', 'Opened', 'Replaced by', 'Website',
      # 'Flash Pass Available', 'Must transfer from wheelchair', 'Theme',
       #'Single rider line available', 'Restraint Style',
      # 'Flash Pass available', 'Acceleration', 'Restraints', 'Name',
       'year_introduced', 'latitude', 'longitude', 
     'Type_Main',
       'opening_date_clean', 
    # 'speed1', 'speed2', 
     'speed1_value', 'speed1_unit',
       'speed_mph', 'height_value', 
     #'height_unit', 'height_ft',
       'Inversions_clean', 'Gforce_clean']].copy()
```


```python
df.shape
```




    (1087, 15)




```python
df.dtypes
```




    coaster_name           object
    Location               object
    Status                 object
    Inversions            float64
    year_introduced         int64
    latitude              float64
    longitude             float64
    Type_Main              object
    opening_date_clean     object
    speed1_value          float64
    speed1_unit            object
    speed_mph             float64
    height_value          float64
    Inversions_clean        int64
    Gforce_clean          float64
    dtype: object




```python
# for date time function 
df['opening_date_clean'] = pd.to_datetime(df['opening_date_clean'])
```


```python
df.dtypes
```




    coaster_name                  object
    Location                      object
    Status                        object
    Inversions                   float64
    year_introduced                int64
    latitude                     float64
    longitude                    float64
    Type_Main                     object
    opening_date_clean    datetime64[ns]
    speed1_value                 float64
    speed1_unit                   object
    speed_mph                    float64
    height_value                 float64
    Inversions_clean               int64
    Gforce_clean                 float64
    dtype: object



# Rename our columns for better understanding 


```python
df.columns
```




    Index(['coaster_name', 'Location', 'Status', 'Inversions', 'year_introduced',
           'latitude', 'longitude', 'Type_Main', 'opening_date_clean',
           'speed1_value', 'speed1_unit', 'speed_mph', 'height_value',
           'Inversions_clean', 'Gforce_clean'],
          dtype='object')




```python
df = df.rename(columns={'coaster_name':'Coaster_Name',
                   'year_introduced':'Year_Introduced',
                   'opening_date_clean':'Opening_Date',
                   'speed_mph':'Speed_mph',
                   'height_ft':'Height_ft',
                   'Inversions_clean':'Inversions',
                   'Gforce_clean':'Gforce'})
```


```python
# Checking for null or missing values 
df.isna().sum()
```




    Coaster_Name         0
    Location             0
    Status             213
    Inversions         155
    Year_Introduced      0
    latitude           275
    longitude          275
    Type_Main            0
    Opening_Date       250
    speed1_value       150
    speed1_unit        150
    Speed_mph          150
    height_value       122
    Inversions           0
    Gforce             725
    dtype: int64




```python
df
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Coaster_Name</th>
      <th>Location</th>
      <th>Status</th>
      <th>Inversions</th>
      <th>Year_Introduced</th>
      <th>latitude</th>
      <th>longitude</th>
      <th>Type_Main</th>
      <th>Opening_Date</th>
      <th>speed1_value</th>
      <th>speed1_unit</th>
      <th>Speed_mph</th>
      <th>height_value</th>
      <th>Inversions</th>
      <th>Gforce</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Switchback Railway</td>
      <td>Coney Island</td>
      <td>Removed</td>
      <td>NaN</td>
      <td>1884</td>
      <td>40.5740</td>
      <td>-73.9780</td>
      <td>Wood</td>
      <td>1884-06-16</td>
      <td>6.0</td>
      <td>mph</td>
      <td>6.0</td>
      <td>50.0</td>
      <td>0</td>
      <td>2.9</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Flip Flap Railway</td>
      <td>Sea Lion Park</td>
      <td>Removed</td>
      <td>1.0</td>
      <td>1895</td>
      <td>40.5780</td>
      <td>-73.9790</td>
      <td>Wood</td>
      <td>1895-01-01</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>12.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Switchback Railway (Euclid Beach Park)</td>
      <td>Cleveland, Ohio, United States</td>
      <td>Closed</td>
      <td>NaN</td>
      <td>1896</td>
      <td>41.5800</td>
      <td>-81.5700</td>
      <td>Other</td>
      <td>NaT</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Loop the Loop (Coney Island)</td>
      <td>Other</td>
      <td>Removed</td>
      <td>1.0</td>
      <td>1901</td>
      <td>40.5745</td>
      <td>-73.9780</td>
      <td>Steel</td>
      <td>1901-01-01</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Loop the Loop (Young's Pier)</td>
      <td>Other</td>
      <td>Removed</td>
      <td>1.0</td>
      <td>1901</td>
      <td>39.3538</td>
      <td>-74.4342</td>
      <td>Steel</td>
      <td>1901-01-01</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>1082</th>
      <td>American Dreier Looping</td>
      <td>Other</td>
      <td>NaN</td>
      <td>3.0</td>
      <td>2022</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Steel</td>
      <td>NaT</td>
      <td>53.0</td>
      <td>mph</td>
      <td>53.0</td>
      <td>111.0</td>
      <td>3</td>
      <td>4.7</td>
    </tr>
    <tr>
      <th>1083</th>
      <td>Pantheon (roller coaster)</td>
      <td>Busch Gardens Williamsburg</td>
      <td>Under construction</td>
      <td>2.0</td>
      <td>2022</td>
      <td>37.2339</td>
      <td>-76.6426</td>
      <td>Steel</td>
      <td>2022-01-01</td>
      <td>73.0</td>
      <td>mph</td>
      <td>73.0</td>
      <td>178.0</td>
      <td>2</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1084</th>
      <td>Tron Lightcycle Power Run</td>
      <td>Other</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>2022</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Steel</td>
      <td>2016-06-16</td>
      <td>59.3</td>
      <td>mph</td>
      <td>59.3</td>
      <td>78.1</td>
      <td>0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>1085</th>
      <td>Tumbili</td>
      <td>Kings Dominion</td>
      <td>Under construction</td>
      <td>0.0</td>
      <td>2022</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Steel</td>
      <td>NaT</td>
      <td>34.0</td>
      <td>mph</td>
      <td>34.0</td>
      <td>112.0</td>
      <td>0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>1086</th>
      <td>Wonder Woman Flight of Courage</td>
      <td>Six Flags Magic Mountain</td>
      <td>Under construction</td>
      <td>3.0</td>
      <td>2022</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Steel</td>
      <td>2022-01-01</td>
      <td>58.0</td>
      <td>mph</td>
      <td>58.0</td>
      <td>131.0</td>
      <td>3</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
<p>1087 rows × 15 columns</p>
</div>




```python
# to identify and return rows in a Pandas DataFrame that are duplicates based on all columns.
df.loc[df.duplicated()]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Coaster_Name</th>
      <th>Location</th>
      <th>Status</th>
      <th>Inversions</th>
      <th>Year_Introduced</th>
      <th>latitude</th>
      <th>longitude</th>
      <th>Type_Main</th>
      <th>Opening_Date</th>
      <th>speed1_value</th>
      <th>speed1_unit</th>
      <th>Speed_mph</th>
      <th>height_value</th>
      <th>Inversions</th>
      <th>Gforce</th>
    </tr>
  </thead>
  <tbody>
  </tbody>
</table>
</div>




```python
df.duplicated()
```




    0       False
    1       False
    2       False
    3       False
    4       False
            ...  
    1082    False
    1083    False
    1084    False
    1085    False
    1086    False
    Length: 1087, dtype: bool




```python
# Check for duplicate coaster name
a = df.loc[df.duplicated(subset=['Coaster_Name'])]
a.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Coaster_Name</th>
      <th>Location</th>
      <th>Status</th>
      <th>Inversions</th>
      <th>Year_Introduced</th>
      <th>latitude</th>
      <th>longitude</th>
      <th>Type_Main</th>
      <th>Opening_Date</th>
      <th>speed1_value</th>
      <th>speed1_unit</th>
      <th>Speed_mph</th>
      <th>height_value</th>
      <th>Inversions</th>
      <th>Gforce</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>43</th>
      <td>Crystal Beach Cyclone</td>
      <td>Crystal Beach Park</td>
      <td>Removed</td>
      <td>NaN</td>
      <td>1927</td>
      <td>42.8617</td>
      <td>-79.0598</td>
      <td>Wood</td>
      <td>1926-01-01</td>
      <td>60.0</td>
      <td>mph</td>
      <td>60.0</td>
      <td>96.0</td>
      <td>0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>60</th>
      <td>Derby Racer</td>
      <td>Revere Beach</td>
      <td>Removed</td>
      <td>0.0</td>
      <td>1937</td>
      <td>42.4200</td>
      <td>-70.9860</td>
      <td>Wood</td>
      <td>1911-01-01</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>61</th>
      <td>Blue Streak (Conneaut Lake)</td>
      <td>Conneaut Lake Park</td>
      <td>Closed</td>
      <td>0.0</td>
      <td>1938</td>
      <td>41.6349</td>
      <td>-80.3180</td>
      <td>Wood</td>
      <td>1938-05-23</td>
      <td>50.0</td>
      <td>mph</td>
      <td>50.0</td>
      <td>77.0</td>
      <td>0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>167</th>
      <td>Big Thunder Mountain Railroad</td>
      <td>Other</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>1980</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Steel</td>
      <td>NaT</td>
      <td>35.0</td>
      <td>mph</td>
      <td>35.0</td>
      <td>104.0</td>
      <td>0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>237</th>
      <td>Thunder Run (Canada's Wonderland)</td>
      <td>Canada's Wonderland</td>
      <td>Operating</td>
      <td>0.0</td>
      <td>1986</td>
      <td>43.8427</td>
      <td>-79.5423</td>
      <td>Steel</td>
      <td>1981-05-23</td>
      <td>64.0</td>
      <td>km/h</td>
      <td>39.8</td>
      <td>10.0</td>
      <td>0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>239</th>
      <td>La Vibora</td>
      <td>Other</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>1986</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Steel</td>
      <td>NaT</td>
      <td>32.0</td>
      <td>mph</td>
      <td>32.0</td>
      <td>60.0</td>
      <td>0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>241</th>
      <td>Big Thunder Mountain Railroad</td>
      <td>Other</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>1987</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Steel</td>
      <td>NaT</td>
      <td>35.0</td>
      <td>mph</td>
      <td>35.0</td>
      <td>104.0</td>
      <td>0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>252</th>
      <td>La Vibora</td>
      <td>Other</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>1987</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Steel</td>
      <td>NaT</td>
      <td>32.0</td>
      <td>mph</td>
      <td>32.0</td>
      <td>60.0</td>
      <td>0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>262</th>
      <td>Flashback (Six Flags Magic Mountain)</td>
      <td>Other</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>1988</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Steel</td>
      <td>NaT</td>
      <td>35.0</td>
      <td>mph</td>
      <td>35.0</td>
      <td>86.0</td>
      <td>0</td>
      <td>3.0</td>
    </tr>
    <tr>
      <th>270</th>
      <td>Alpine Bobsled</td>
      <td>Other</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>1989</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>Steel</td>
      <td>NaT</td>
      <td>35.0</td>
      <td>mph</td>
      <td>35.0</td>
      <td>64.0</td>
      <td>0</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python
# Checking an example duplicate
df.query('Coaster_Name == "Crystal Beach Cyclone"')
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Coaster_Name</th>
      <th>Location</th>
      <th>Status</th>
      <th>Inversions</th>
      <th>Year_Introduced</th>
      <th>latitude</th>
      <th>longitude</th>
      <th>Type_Main</th>
      <th>Opening_Date</th>
      <th>speed1_value</th>
      <th>speed1_unit</th>
      <th>Speed_mph</th>
      <th>height_value</th>
      <th>Inversions</th>
      <th>Gforce</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>39</th>
      <td>Crystal Beach Cyclone</td>
      <td>Crystal Beach Park</td>
      <td>Removed</td>
      <td>NaN</td>
      <td>1926</td>
      <td>42.8617</td>
      <td>-79.0598</td>
      <td>Wood</td>
      <td>1926-01-01</td>
      <td>60.0</td>
      <td>mph</td>
      <td>60.0</td>
      <td>96.0</td>
      <td>0</td>
      <td>4.0</td>
    </tr>
    <tr>
      <th>43</th>
      <td>Crystal Beach Cyclone</td>
      <td>Crystal Beach Park</td>
      <td>Removed</td>
      <td>NaN</td>
      <td>1927</td>
      <td>42.8617</td>
      <td>-79.0598</td>
      <td>Wood</td>
      <td>1926-01-01</td>
      <td>60.0</td>
      <td>mph</td>
      <td>60.0</td>
      <td>96.0</td>
      <td>0</td>
      <td>4.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
df.columns
```




    Index(['Coaster_Name', 'Location', 'Status', 'Inversions', 'Year_Introduced',
           'latitude', 'longitude', 'Type_Main', 'Opening_Date', 'speed1_value',
           'speed1_unit', 'Speed_mph', 'height_value', 'Inversions', 'Gforce'],
          dtype='object')




```python
df = df.loc[~df.duplicated(subset=['Coaster_Name','Location','Opening_Date'])] \
    .reset_index(drop=True).copy()
```


```python
df.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Coaster_Name</th>
      <th>Location</th>
      <th>Status</th>
      <th>Inversions</th>
      <th>Year_Introduced</th>
      <th>latitude</th>
      <th>longitude</th>
      <th>Type_Main</th>
      <th>Opening_Date</th>
      <th>speed1_value</th>
      <th>speed1_unit</th>
      <th>Speed_mph</th>
      <th>height_value</th>
      <th>Inversions</th>
      <th>Gforce</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Switchback Railway</td>
      <td>Coney Island</td>
      <td>Removed</td>
      <td>NaN</td>
      <td>1884</td>
      <td>40.5740</td>
      <td>-73.9780</td>
      <td>Wood</td>
      <td>1884-06-16</td>
      <td>6.0</td>
      <td>mph</td>
      <td>6.0</td>
      <td>50.0</td>
      <td>0</td>
      <td>2.9</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Flip Flap Railway</td>
      <td>Sea Lion Park</td>
      <td>Removed</td>
      <td>1.0</td>
      <td>1895</td>
      <td>40.5780</td>
      <td>-73.9790</td>
      <td>Wood</td>
      <td>1895-01-01</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>12.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Switchback Railway (Euclid Beach Park)</td>
      <td>Cleveland, Ohio, United States</td>
      <td>Closed</td>
      <td>NaN</td>
      <td>1896</td>
      <td>41.5800</td>
      <td>-81.5700</td>
      <td>Other</td>
      <td>NaT</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>0</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Loop the Loop (Coney Island)</td>
      <td>Other</td>
      <td>Removed</td>
      <td>1.0</td>
      <td>1901</td>
      <td>40.5745</td>
      <td>-73.9780</td>
      <td>Steel</td>
      <td>1901-01-01</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>NaN</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Loop the Loop (Young's Pier)</td>
      <td>Other</td>
      <td>Removed</td>
      <td>1.0</td>
      <td>1901</td>
      <td>39.3538</td>
      <td>-74.4342</td>
      <td>Steel</td>
      <td>1901-01-01</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>1</td>
      <td>NaN</td>
    </tr>
  </tbody>
</table>
</div>




```python

```

# Step 3 - Understanding features

Plotting distributuins\
Histogram\
KDE plot\
Boxplot\


```python
df['Year_Introduced'].value_counts()
```




    1999    46
    2000    45
    1998    30
    2001    29
    2002    28
            ..
    1956     1
    1959     1
    1961     1
    1895     1
    1884     1
    Name: Year_Introduced, Length: 101, dtype: int64




```python
## For boxplot 

ax = df['Year_Introduced'].value_counts() \
    .head(10) \
    .plot(kind='bar', title='Top 10 Years Coasters Introduced', color='red')
ax.set_xlabel('Year Introduced')
ax.set_ylabel('Count')
```




    Text(0, 0.5, 'Count')




    
![png](output_25_1.png)
    



```python
# for histogram 
ax = df['Speed_mph'].plot(kind='hist',
                          bins=20,
                          title='Coaster Speed (mph)',
                        color = 'red')
ax.set_xlabel('Speed (mph)')
```




    Text(0.5, 0, 'Speed (mph)')




    
![png](output_26_1.png)
    



```python
# KDE plot 
ax = df['Speed_mph'].plot(kind='kde',
                          title='Coaster Speed (mph)',
                          color = 'red')
ax.set_xlabel('Speed (mph)')
```




    Text(0.5, 0, 'Speed (mph)')




    
![png](output_27_1.png)
    


# Understanding Feature relationship¶
Scatterplot\
Heatmap Correlation\
Pairplot\
Groupby comparisons\


```python
# for scatterplot
df.plot(kind='scatter',
        x='Speed_mph',
        y='Gforce',
        title='Coaster Speed vs. Gforce')
plt.show()
```


    
![png](output_29_0.png)
    



```python
ax = sns.scatterplot(x='Speed_mph',
                y='height_value',
                hue='Year_Introduced',
                data=df)
ax.set_title('Coaster Speed vs. height_value')
plt.show()
```


    
![png](output_30_0.png)
    



```python

```


```python
# finding co-relation between following columns 
df_corr = df[['Year_Introduced','Speed_mph',
    #'Height_ft',
              'Inversions','Gforce']].dropna().corr()
df_corr
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Year_Introduced</th>
      <th>Speed_mph</th>
      <th>Inversions</th>
      <th>Inversions</th>
      <th>Gforce</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Year_Introduced</th>
      <td>1.000000</td>
      <td>0.208507</td>
      <td>0.125260</td>
      <td>0.125260</td>
      <td>0.080185</td>
    </tr>
    <tr>
      <th>Speed_mph</th>
      <td>0.208507</td>
      <td>1.000000</td>
      <td>0.103886</td>
      <td>0.103886</td>
      <td>0.467064</td>
    </tr>
    <tr>
      <th>Inversions</th>
      <td>0.125260</td>
      <td>0.103886</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.402441</td>
    </tr>
    <tr>
      <th>Inversions</th>
      <td>0.125260</td>
      <td>0.103886</td>
      <td>1.000000</td>
      <td>1.000000</td>
      <td>0.402441</td>
    </tr>
    <tr>
      <th>Gforce</th>
      <td>0.080185</td>
      <td>0.467064</td>
      <td>0.402441</td>
      <td>0.402441</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
#we use heatmap for better understanding of co-relation 
ax=sns.heatmap(df_corr, annot=True)
```


    
![png](output_33_0.png)
    


Getting answer for the row 10 fastest roller coaster


```python
ax = df.query('Location != "other"').groupby('Location')['Speed_mph'].agg(['mean','count']).query('count>=10').sort_values('mean')['mean']\
    .plot(kind='barh',figsize=(13,8), color='red')

ax.set_xlabel('Avg. Coaster Speed')
```




    Text(0.5, 0, 'Avg. Coaster Speed')




    
![png](output_35_1.png)
    



```python

```


```python
import pandas as pd
import numpy as np
import matplotlib.pylab as plt
import seaborn as sns
plt.style.use('ggplot')
```


```python
df=pd.read_csv('C:/Users/LENOVO X260/Desktop/seyi/coaster_db.csv')
```


```python
plt.close();
sns.set_style("whitegrid")
sns.pairplot(df,hue="Type_Main" );
plt.show()
```


    
![png](output_39_0.png)
    



```python

```
